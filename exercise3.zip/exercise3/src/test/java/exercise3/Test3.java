package exercise3;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.theories.suppliers.TestedOn;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;

import exercise3.ClsBrowser;
//import selenium.ClsReport;
//import selenium.ClsReport;
import exercise3.AddToCart;
import exercise3.AddToCart;

public class Test3 extends ClsBrowser{

	AddToCart addToCart;
	AddToCart2 addToCart2;
	Register addToCart3;
	
	/*
	@BeforeMethod
	public static void beforeClass() 
	{
		ClsReport.fnSetupReport();
	}
	*/

	@Before
	public void setUp() throws Exception {
		addToCart = new AddToCart();
		addToCart2 = new AddToCart2();
		addToCart3  = new Register();
		ClsBrowser.BrowserName = "Chrome";
		OpenBrowser();
	}

	@After
	public void tearDown() throws Exception {
		CloseBrowser();
		//ClsReport.fnCloseReport();
	}

	@Test
	public void test1() {
		NavigateToUrl("http://live.guru99.com/index.php/tv.html");
		addToCart.AddToCart();
	}
	
	@Test
	public void test2() {
		NavigateToUrl("http://live.guru99.com/index.php/tv.html");
		addToCart2.AddToCart2();
	}
	
	@Test
	public void test3() {
		NavigateToUrl("http://live.guru99.com/index.php/tv.html");
		addToCart3.AddToCart3();
		
		
	}
	
}
