package exercise3;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AddToCart extends ClsBrowser {
	//Locators
	By addToCart =  By.xpath("//span[contains(text(),'Add to Cart')]");
	By addTelevision = By.id("//*[@id=\"top\"]");
	
	public void AddToCart() {
		
		 try 
         {
			 if(isDisplayed(addToCart)) {
					WaitForLoad();
					click(addToCart);
					WaitForLoad();
				}
				else {
				    System.out.print("An error occurred during the execution");
				}
         
         
          }catch(Exception e) 
          {
	      System.out.println("The element was not located in the page");
           return;
           }
	
	}
	
		
	}


