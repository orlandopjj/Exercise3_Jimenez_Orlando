package exercise3;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

public class Register extends ClsBrowser {
	//Locators
	By registerBtn = By.xpath("//*[@id=\"header\"]/div/div[2]/div/a/span[2]");
	//By accountBtn = By.xpath("//*[@id=\"header-account\"]/div/ul/li[6]/a");
	
	By createBtn = By.xpath("//*[@id=\"login-form\"]/div/div[1]/div[2]/a/span/span");
	By accountBtn2 = By.xpath("//*[@id=\"header-account\"]/div/ul/li[6]/a");
	By nameBtn = By.id("firstname");	
	By mBtn = By.id("middlename");
	By lBtn = By.id("lastname");
	By eaBtn = By.id("email_address");
	By passBtn = By.id("password");
	By conBtn = By.id("confirmation");
	By regBtn = By.xpath("//*[@id=\"form-validate\"]");
	
	By finalBtn = By.xpath("//*[@id=\"form-validate\"]/div[2]/button");
	//click(accountBtn);
	public void AddToCart3(){
		
		
		
		if(isDisplayed(registerBtn)) {
			
			
			 try 
	         {
				 WaitForLoad();
					click(registerBtn);
					WaitForLoad();
					click(accountBtn2);
					WaitForLoad();
					click(createBtn);
					WaitForLoad();
					
					
					click(nameBtn);
					type("Orlando",nameBtn);
					WaitForLoad();
					click(mBtn);
					type("Porfirio",mBtn);
					WaitForLoad();
					click(lBtn);
					type("Jimenez",lBtn);
					WaitForLoad();
					click(eaBtn);
					type("al9964472@gmail.com",eaBtn);
					WaitForLoad();
					click(passBtn);
					type("al9964472$%&",passBtn);
					WaitForLoad();
					click(conBtn);
					type("al9964472$%&",conBtn);
					WaitForLoad();
					click(finalBtn);
				
	         
	          }catch(Exception e) 
	          {
		      System.out.println("Test Finished");
               return;
	           }
			
			
			
		} else {
			System.out.println("An error occurred during the execution");
		}
		
		
		
		}
	

}
