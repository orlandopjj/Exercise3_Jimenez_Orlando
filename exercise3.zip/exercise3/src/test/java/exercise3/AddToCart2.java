package exercise3;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;;

public class AddToCart2 extends ClsBrowser {
	//Locators
	//(//span[contains(text(),'Add to Cart')])[2]
	By addToCart2 = By.xpath("(//span[contains(text(),'Add to Cart')])[2]");
	By checkoutBtn = By.xpath("//span[contains(text(),'Proceed to Checkout')]");
	By continueBtn = By.id("onepage-guest-register-button");
	By checkoutBtn2 = By.xpath("//*[@id=\"opc-login\"]");
	By continueBtn2 = By.id("onepage-guest-register-button");
	By bnBtn = By.id("billing:firstname");
	By mnBtn = By.id("billing:middlename");
	By fnBtn = By.id("billing:lastname");
	By cnBtn = By.id("billing:company");
	By eaBtn = By.id("billing:email");
	By addBtn = By.id("billing:street1");
	By stBtn = By.id("billing:street2");
	By cityBtn = By.id("billing:city");
	By regionBtn  =By.id("billing:region_id");
	//By countryBtn = By.id("//*[@id=\"billing:region_id\"]/option[2]");
	By zipBtn = By.id("billing:postcode");
	By telephoneBtn = By.id("billing:telephone");
	By faxBtn = By.id("billing:fax");
	By lastcBtn = By.xpath("//*[@id=\"billing-buttons-container\"]/button");
	
	By lastcBtn2 = By.xpath("//*[@id=\"shipping-method-buttons-container\"]/button/span/span");
	By checkBtn  =By.xpath("//*[@id=\"dt_method_checkmo\"]/label");
	By placeorderBtn = By.xpath("//*[@id=\"review-buttons-container\"]/button/span/span");
	
	//By continueshoppBtn = By.xpath("//*[@id=\"top\"]/body/div/div/div[2]/div/div/div[2]/button/span/span");
	public void AddToCart2() {
		
		
	
		if(isDisplayed(addToCart2)) {
			WaitForLoad();
			click(addToCart2);
			WaitForLoad();
			if(isDisplayed(checkoutBtn)) {
				WaitForLoad();
				click(checkoutBtn);
				WaitForLoad();
				click(continueBtn);
				WaitForLoad();
				 try 
    	         {
					 
    	         click(checkoutBtn2);
    	         
    	          }catch(Exception e) 
    	          {
    		      System.out.println("The element was not located in the page");
                   return;
    	           }
				WaitForLoad();
				click(continueBtn2);
				WaitForLoad();
				click(bnBtn);
				type("Orlando",bnBtn);
				WaitForLoad();
				click(mnBtn);
				type("Porfirio",mnBtn);
				WaitForLoad(); 
				type("Jimenez",fnBtn);
				WaitForLoad();
				click(cnBtn);
				type("AgileThought",cnBtn);
				WaitForLoad();
				click(eaBtn);
				type("al9964472@gmail.com",eaBtn);
				WaitForLoad();
				click(addBtn);
				type("Avenida Central n�mero 120",addBtn);
				WaitForLoad();
				click(stBtn);
				type("H�roes de Padierna",stBtn);
				WaitForLoad();
				click(cityBtn);
				type("Mexico City",cityBtn);
				WaitForLoad();
				click(regionBtn);
				WaitForLoad();
				
				Select oldStyleMenu = new Select(objDriver.findElement(By.id("billing:region_id")));
				oldStyleMenu.selectByIndex(1);
				WaitForLoad();
				click(zipBtn);
				type("15500",zipBtn);
				WaitForLoad();
				
				Select oldStyleMenu2 = new Select(objDriver.findElement(By.id("billing:country_id")));
				oldStyleMenu2.selectByIndex(141);
				WaitForLoad();
				click(telephoneBtn);
				type("5558974863",telephoneBtn);
				WaitForLoad();
				click(faxBtn);
				type("17896521",faxBtn);
				
				WaitForLoad();
				click(lastcBtn);
				WaitForLoad();
			
				click(lastcBtn2);
				WaitForLoad();
			    click(checkBtn);
				WaitForLoad();
				
				 try 
    	         {
					 
					 click(placeorderBtn);
    	         
    	          }catch(Exception e) 
    	          {
    		      System.out.println("Test Finished");
                   return;
    	           }
				
				
				
				WaitForLoad();
				
			}else {
				System.out.println("An error occurred during the execution");
			}
			
		}else {
			System.out.println("An error occurred during the execution");
		}
	}	
}
